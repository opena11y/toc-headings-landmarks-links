/* utils.js */

/* imports */

import DebugLogging   from './debug.js';


/* Utility functions */

const browserI18n = typeof browser === 'object' ?
            browser.i18n :
            chrome.i18n;

const debug = new DebugLogging('utils', false);
debug.flag = false;

/*
**  @function getSpan
*/

export function getSpanBrackets(content, cName="", ariaLabel="", lb="(", rb=")") {
  const span1 =  document.createElement('span');
  span1.className = 'brackets';
  if (ariaLabel) {
    span1.ariaLabel = ariaLabel;
  }

  const left = document.createTextNode(lb);
  span1.appendChild(left);

  const span2 =  document.createElement('span');
  span2.textContent = content;
  span2.className = cName;
  span1.appendChild(span2)

  const right = document.createTextNode(rb);
  span1.appendChild(right);

  return span1;
}

/*
**  @function getSpan
*/

export function getSpan(content, cName="", ariaLabel="") {
  const span =  document.createElement('span');
  span.textContent = content;
  span.className = cName;
  if (ariaLabel) {
    span.ariaLabel = ariaLabel;
  }
  return span;
}

/*
**  @function removeChildContent
*/

export function removeChildContent(node) {
   while(node.firstChild) {
    node.removeChild(node.firstChild);
   }
}

/*
**  @function setI18nLabels
*/

export function getMessage (id, debug=false) {
  const msg = browserI18n.getMessage(id);
  return msg ? msg + (debug ? ' (i18n)' : '') : `message not found: ${id}`;
}

/*
**  @function setI18nLabels
*/

export function setI18nLabels (docNode, debug=false) {
    const i18nLabels =  Array.from(docNode.querySelectorAll('[data-i18n]'));

    i18nLabels.forEach( node => {
      const label = browserI18n.getMessage(node.getAttribute('data-i18n'));
      if (label) {
        node.textContent = label + (debug ? ' (i18n)' : '');
      }
      else {
        console.error(`[i18n][node][ textContent]: ${node.getAttribute('data-i18n')}`);
        console.error(`[i18n][label][textContent]: ${label}`);
      }
    });

    const i18nLabelsAriaLabel =  Array.from(docNode.querySelectorAll('[data-i18n-aria-label]'));

    i18nLabelsAriaLabel.forEach( node => {
      const label = browserI18n.getMessage(node.getAttribute('data-i18n-aria-label'));
      if (label) {
        node.setAttribute('aria-label', label + (debug ? ' (i18n)' : ''));
      }
      else {
        console.error(`[node][ aria-label]: ${node.getAttribute('data-i18n-aria-label')}`);
        console.error(`[label][aria-label]: ${label}`);
      }
    });

    const i18nLabelsTitle =  Array.from(docNode.querySelectorAll('[data-i18n-title]'));

    i18nLabelsTitle.forEach( node => {
      const label = browserI18n.getMessage(node.getAttribute('data-i18n-title'));
      if (label) {
        node.title = label + (debug ? ' (i18n)' : '');
      }
      else {
        console.error(`[node][ title]: ${node.getAttribute('data-i18n-aria-label')}`);
        console.error(`[label][title]: ${label}`);
      }
    });

  }

/*
**  @function setTablistAttr
*/

export function setTablistAttr (attr, value) {
    const sidepanelNode = document.querySelector('h2l-sidepanel');
    const tablistNode   = sidepanelNode.shadowRoot.querySelector('h2l-tablist');
    if (tablistNode) {
      tablistNode.setAttribute(attr, value);
    }
  }

/*
**  @function updateContent
*/

export function updateContent () {
  const sidepanelNode = document.querySelector('h2l-sidepanel');
  if (sidepanelNode) {
    sidepanelNode.updateContent();
  }
}

/*
**  @function highlightItems
*/

export function highlightItems (selectedItem={}, allItems=[], msgHidden, showName) {
  const sidepanelNode = document.querySelector('h2l-sidepanel');
  if (sidepanelNode) {
    sidepanelNode.highlightItems(selectedItem, allItems, msgHidden, showName);
  }
}

/*
**  @function updateHighlightConfig
*/

export function updateHighlightConfig (options) {
  const sidepanelNode = document.querySelector('h2l-sidepanel');
  if (sidepanelNode) {
    sidepanelNode.updateHighlightConfig(options);
  }
}


/*
**  @function filterForCSV
*/

export function filterForCSV (str) {
  let filteredStr = '';
  if (typeof str === 'string') {
    for(let i=0; i < str.length; i += 1) {
      const c = str[i];
      if (!'"\n\r'.includes(c)) {
        filteredStr += c;
      }
    }
  }
  return filteredStr;
}

